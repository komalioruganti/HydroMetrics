const avg = [
"4.15","3.28","1",""
] 
export default avg;