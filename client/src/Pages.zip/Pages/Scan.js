import { WebcamCapture } from "../Components/Camera"
export default function Scan(){
return (
<>
<WebcamCapture></WebcamCapture>
</>
)
}